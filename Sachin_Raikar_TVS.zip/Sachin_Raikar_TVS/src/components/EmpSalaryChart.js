import React, { useEffect, useState } from "react";
import Paper from "@material-ui/core/Paper";
import {
  Chart,
  BarSeries,
  ArgumentAxis,
  ValueAxis,
} from "@devexpress/dx-react-chart-material-ui";
import { Animation } from "@devexpress/dx-react-chart";
import { useSelector } from "react-redux";
import { Card, Typography, Divider } from "antd";

const { Title } = Typography;

function EmpSalaryChart() {
  const dataList = useSelector(
    (state) => state.users?.apiResponseData?.TABLE_DATA?.data
  );

  const [chartData, setChartData] = useState("");

  useEffect(() => {
    let isLoggedIn = localStorage.getItem("loggedIn");
    if (!isLoggedIn) {
      alert("You need to login!");
      window.location = "/login";
      window.close();
    }
  }, []);
  useEffect(() => {
    let chart = [];
    for (let i = 0; i <= 9; i++) {
      let formatVal = dataList[i][5].split("$")[1];
      let record = {
        text: dataList[i][0],
        value: parseInt(formatVal.replace(",", "")),
      };
      chart.push(record);
    }
    setChartData(chart);
  }, [dataList]);
  return (
    <div>
      <Card
        className="barCard"
        style={{
          width: 1250,
          margin: "20px",
          borderRadius: "20px",
          overflow: "hidden",
          backgroundColor: "#ececec",
          height: 600,
        }}
      >
        <b>Employee Salary</b>
        <Divider
          style={{
            marginBottom: "20px",
            backgroundColor: "#909090",
            marginTop: "0px",
          }}
        />
        <Paper>
          <Chart data={chartData || []}>
            <ArgumentAxis />
            <ValueAxis max={11} />

            <BarSeries valueField="value" argumentField="text" />
            <Title text="World population" />
            <Animation />
          </Chart>
        </Paper>
      </Card>
    </div>
  );
}

export default EmpSalaryChart;