import React, { useEffect, useState, useRef } from "react";
import { useSelector, useDispatch } from "react-redux";
import { getUserData } from "../redux/actions/usersAction";
import { Card, Input, Col, Row, Divider, Typography, List, Button } from "antd";
import Webcam from "react-webcam";
import PhotoResult from "./PhotoResult";

const { Title } = Typography;

const videoConstraints = {
  width: 1280,
  height: 720,
  facingMode: "user",
};

function Details() {
  const [image, setImage] = useState("");
  const [timestamp, setTimeStamp] = useState("");

  const webcamRef = React.useRef(null);

  useEffect(() => {
    let isLoggedIn = localStorage.getItem("loggedIn");
    if (!isLoggedIn) {
      alert("You need to login!");
      window.location = '/login'
      window.close();
    }
  }, [timestamp]);

  const capture = React.useCallback(() => {
    const imageSrc = webcamRef.current.getScreenshot();
    setImage(imageSrc);
    let timestamp = new Date();
    setTimeStamp(timestamp.toLocaleString());
  }, [webcamRef]);

  const getData = (item) => {
    let empData = localStorage.getItem("empData");
    if (empData) {
      empData = JSON.parse(empData);
      return empData[item];
    }
  };

  if (image) {
    return <PhotoResult src={image} timestamp={timestamp} />;
  }

  return (
    <div>
      <Card
        className="detailsCard"
        style={{
          width: 850,
          margin: "20px",
          borderRadius: "20px",
          overflow: "hidden",
          backgroundColor: "#ececec",
          height: 600,
        }}
        title={<Title level={3}>Employee Details</Title>}
      >
        <Divider
          style={{ marginBottom: "20px", color: "black", marginTop: "0px" }}
        />
        <Row gutter={4}>
          <Col>Employee Name -</Col>
          <Col>{getData("name")}</Col>
        </Row>
        <Row gutter={4}>
          <Col>Designation -</Col>
          <Col>{getData("designation")}</Col>
        </Row>
        <Row gutter={4}>
          <Col>Address -</Col>
          <Col>{getData("address")}</Col>
        </Row>
        <Row gutter={4}>
          <Col>Employee Id -</Col>
          <Col>{getData("empId")}</Col>
        </Row>
        <Row gutter={4}>
          <Col>Employee DoJ -</Col>
          <Col>{getData("doj")}</Col>
        </Row>
        <Row gutter={4}>
          <Col>Salary -</Col>
          <Col>{getData("salary")}</Col>
        </Row>

        <Webcam
          audio={false}
          height={220}
          ref={webcamRef}
          screenshotFormat="image/jpeg"
          width={750}
          videoConstraints={videoConstraints}
        />
        <Button onClick={capture}>Capture photo</Button>
      </Card>
    </div>
  );
}

export default Details;