import React, { useEffect, useState, useRef } from "react";
import { Image, Divider, Card, Typography, Col, Row } from "antd";

const { Title } = Typography;

function PhotoResult(props) {
  return (
    <div>
      <Card
        className="detailsCard"
        style={{
          width: 850,
          margin: "20px",
          borderRadius: "20px",
          overflow: "hidden",
          backgroundColor: "#ececec",
          height: 600,
        }}
        title={<Title level={3}>Photo Result</Title>}
      >
        <Divider
          style={{ marginBottom: "20px", color: "black", marginTop: "0px" }}
        />
        <Image width={600} src={props.src} />
        <Row gutter={8} style={{ marginTop: "20px", marginLeft: "100px" }}>
          <Col>
            <b>Timestamp -</b>
          </Col>
          <Col>{props.timestamp}</Col>
        </Row>
      </Card>
    </div>
  );
}

export default PhotoResult;