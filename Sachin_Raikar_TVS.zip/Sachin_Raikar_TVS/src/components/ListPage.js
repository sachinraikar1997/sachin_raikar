import React, { useEffect, useState } from "react";
import { useSelector, useDispatch } from "react-redux";
import { getUserData, setEmployeeDetails } from "../redux/actions/usersAction";
import { Card, Input, Col, Row, Divider, Typography, List, Button } from "antd";

const { Title } = Typography;

function ListPage() {
  const dispatch = useDispatch();

  const dataList = useSelector(
    (state) => state.users?.apiResponseData?.TABLE_DATA?.data
  );

  const [inputValue, setInputValue] = useState("");
  const [filteredList, setFilteredList] = useState(dataList);
  const [valSelected, setValSelected] = useState(false);

  useEffect(() => {
    let isLoggedIn = localStorage.getItem("loggedIn");
    if (!isLoggedIn) {
      alert("You need to login!");
      window.location = "/login";
      window.close();
    }
    // The following dispatch action calls the api and saves it to the store under 'apiResponseData'
    // Commented since the api request fails because of CORS issue:
    //   Access to fetch at 'https://tvsfit.mytvs.in/reporting/vrm/api/test_new/int/gettabledata.php'
    //   from origin 'http://localhost:3000' has been blocked by CORS policy:
    //   Response to preflight request doesn't pass access control check: It does not have HTTP ok status.
    // dispatch(getUserData())
  }, []);

  useEffect(() => {
    let formattedList = [];
    for (let i = 0; i < dataList.length; i++) {
      let rowData = "";
      for (let j = 0; j < dataList[i].length; j++) {
        if (j == 0) {
          rowData = rowData + dataList[i][j];
        } else {
          rowData = rowData + " - " + dataList[i][j];
        }
      }
      formattedList.push(rowData);
    }
    if (inputValue) {
      setFilteredList(
        filteredList.filter(
          (item) => item.toUpperCase().indexOf(inputValue.toUpperCase()) !== -1
        )
      );
    } else {
      setFilteredList(formattedList);
    }
  }, [dataList, inputValue]);

  const onSearch = (e) => {
    setInputValue(e.target.value);
  };

  const handleListSelect = (item) => {
    setValSelected(item);
    window.open("/details", "_blank");
    dispatch(setEmployeeDetails(item));
  };

  return (
    <div>
      <Card
        className="listCard"
        style={{
          width: 850,
          margin: "20px",
          borderRadius: "20px",
          overflow: "hidden",
          backgroundColor: "#ececec",
          height: 500,
        }}
        title={<Title level={3}>Employee List</Title>}
      >
        <Divider
          style={{
            marginBottom: "20px",
            backgroundColor: "#909090",
            marginTop: "0px",
          }}
        />

        <Row gutter={8} style={{ marginBottom: "20px" }}>
          <Col span={2}>Search :</Col>
          <Col span={22}>
            <Input value={inputValue} onChange={(e) => onSearch(e)} />
          </Col>
        </Row>
        <List
          key="empDetails"
          size="small"
          bordered
          style={{ height: 250, overflow: "auto", backgroundColor: "white" }}
          dataSource={filteredList || []}
          renderItem={(item) =>
            item && (
              <List.Item
                key={item}
                style={{
                  cursor: "pointer",
                  background: valSelected === item ? "#1890ff" : "transparent",
                  color: valSelected === item && "#ffffff",
                }}
                onClick={() => handleListSelect(item)}
              >
                {item}
                {/* item is like s3cw-e-708.ne so, removing .ne when rendering to user*/}
              </List.Item>
            )
          }
        ></List>
        <Button onClick={(e) => (window.location = "/barChart")}>
          Show Bar Chart
        </Button>
      </Card>
    </div>
  );
}

export default ListPage;