import React, { useEffect } from "react";
import logo from "../logo.png";
import { Link } from "react-router-dom";

function NavBar() {
  useEffect(() => {
    let isLoggedIn = localStorage.getItem("loggedIn");
    if (!isLoggedIn) {
      window.close();
    }
  }, []);

  const logout = (e) => {
    localStorage.clear();
  };
  return (
    <nav>
      <img src={logo} className="tvs-logo" alt="TVS logo" />
      <ul className="nav-links">
        <Link className="navStyle" to="/list">
          <li>List Page</li>
        </Link>
        <Link className="navStyle" to="/details">
          <li>Details Page</li>
        </Link>
        <Link className="navStyle" to="/login" onClick={(e) => logout(e)}>
          <li>Logout</li>
        </Link>
      </ul>
    </nav>
  );
}

export default NavBar;