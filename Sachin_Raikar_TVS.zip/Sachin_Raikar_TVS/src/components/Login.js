import React, { useEffect, useState } from "react";
import { useSelector, useDispatch } from "react-redux";
import { Space, Card, Input, Form, Button, Divider, Typography } from "antd";

import "../styles/loginStyle.css";
import { getUserData } from "../redux/actions/usersAction";
const { Title } = Typography;

export default function Login() {
  const dispatch = useDispatch();

  const userData = useSelector((state) => state.users?.userData);

  const [submitMsg, setSubmitMsg] = useState("");

  const onFinish = (values) => {
    if (
      values.username === userData.username &&
      values.password === userData.password
    ) {
      setSubmitMsg("Login successful!");
      setTimeout(() => {
        setSubmitMsg("");
        localStorage.setItem("loggedIn", true);
        window.location.href = "/list";
      }, 2000);
    } else {
      setSubmitMsg("Login failed!");
    }
  };

  return (
    <div>
      <Card
        className="cardComp"
        style={{
          width: 400,
          margin: "20px",
          borderRadius: "20px",
          overflow: "hidden",
          backgroundColor: "#ececec",
          height: 300,
        }}
        title={<Title level={3}>Login</Title>}
      >
        <Divider
          style={{
            marginBottom: "20px",
            backgroundColor: "#909090",
            marginTop: "0px",
          }}
        />
        <Form
          name="basic"
          labelCol={{ span: 8 }}
          wrapperCol={{ span: 16 }}
          initialValues={{ remember: true }}
          onFinish={onFinish}
          autoComplete="off"
        >
          <Form.Item
            label="Username"
            name="username"
            rules={[{ required: true, message: "Please input your username!" }]}
          >
            <Input />
          </Form.Item>

          <Form.Item
            label="Password"
            name="password"
            rules={[{ required: true, message: "Please input your password!" }]}
          >
            <Input.Password />
          </Form.Item>

          <Form.Item wrapperCol={{ offset: 4, span: 16 }}>
            <Button type="primary" htmlType="submit">
              Submit
            </Button>
          </Form.Item>
        </Form>
        <span
          style={{ color: submitMsg === "Login successful!" ? "green" : "red" }}
        >
          {submitMsg}
        </span>
      </Card>
    </div>
  );
}