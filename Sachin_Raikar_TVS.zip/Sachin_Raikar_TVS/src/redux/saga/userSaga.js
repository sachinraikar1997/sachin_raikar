import { call, put, takeEvery } from "redux-saga/effects";
import { getUserDataFail, getUserDataSuccess } from "../actions/usersAction";
import { GET_USER_DATA } from "../constants";

const apiUrl =
  "https://tvsfit.mytvs.in/reporting/vrm/api/test_new/int/gettabledata.php";

function request(url, options) {
  if (options.method && options.method === "GET") {
    return fetch(url, {
      method: options.method,
      headers: {
        "Content-Type": "application/json",
      },
    })
      .then((response) => response.json())
      .catch((err) => {
        throw err;
      });
  } else {
    return fetch(url, {
      method: options.method,
      headers: {
        "Content-Type": "application/json",
      },
      body: options.body || "",
    })
      .then((response) => response.json())
      .catch((err) => {
        throw err;
      });
  }
}

export function* fetchData(action) {
  try {
    const requestOptions = {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        username: "test",
        password: "123456",
      }),
    };
    const response = yield call(request, apiUrl, requestOptions);
    yield put(getUserDataSuccess(response));
  } catch (err) {
    yield put(getUserDataFail(err));
  }
}

function* userSaga() {
  yield takeEvery(GET_USER_DATA, fetchData);
}

export default userSaga;