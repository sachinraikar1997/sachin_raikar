import * as constants from "../constants";

export function getUserData() {
  return {
    type: constants.GET_USER_DATA,
  };
}
export function getUserDataSuccess(userData) {
  return {
    type: constants.GET_USER_DATA_SUCCESS,
    payload: userData,
  };
}
export function getUserDataFail(error) {
  return {
    type: constants.GET_USER_DATA_FAIL,
    error,
  };
}

export function setEmployeeDetails(data) {
  return {
    type: constants.SET_EMP_DETAILS,
    data,
  };
}