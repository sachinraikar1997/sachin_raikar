import logo from "./logo.svg";
import "./App.css";
import Login from "./components/Login";
import { BrowserRouter as Router, Switch, Route } from "react-router-dom";
import NavBar from "./components/NavBar";
import "antd/dist/antd.css";
import ListPage from "./components/ListPage";
import Details from "./components/Details";
import EmpSalaryChart from "./components/EmpSalaryChart";

function App() {
  return (
    <div className="App">
      <Router>
        <Switch>
          <Route exact path="/" component={Login} />
          <Route exact path="/login" component={Login} />
          <div>
            <NavBar />
            <Route exact path="/list" component={ListPage} />
            <Route exact path="/details" component={Details} />
            <Route exact path="/barChart" component={EmpSalaryChart} />
          </div>
        </Switch>
      </Router>
    </div>
  );
}

export default App;